SWEA Mandatory Project HotStone
===============================

This is the HotStone project, used for the mandatory project in
the SWEA course, taught at Computer Science, Aarhus University.

*- Henrik Bærbak Christensen*
